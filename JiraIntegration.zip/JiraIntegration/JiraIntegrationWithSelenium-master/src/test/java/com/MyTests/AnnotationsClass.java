package com.MyTests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

import java.util.Random;


public class AnnotationsClass extends BaseTest{


@Test
    public void testcase001() throws InterruptedException {
    WebDriver driver = new ChromeDriver();
    driver.get("https://portal.igbc.in/register");
    System.out.println(driver.getTitle());

    Thread.sleep(9000*3);
    driver.findElement(By.xpath("//input[@id='terms']")).click();




}

@Parameters({"username"})
@Test
    public void testcase002(@Optional String username){
        System.out.println("test 002");

    System.out.println("I am getting val xml " + username);
    }

    public void testcase003(){

    }

    public void randomNumberGeneror(){

      int randomNum = new Random().nextInt();

        System.out.println("Random num" + randomNum);
    }

  /*  @BeforeClass
    public void beforeClass(){
        System.out.println("I am before class  method");
    }

    @BeforeClass
    public void beforeClass2(){
        System.out.println("2222 I am before class  method");
    }

    @BeforeTest
    public void testBeforeAnno(){
        System.out.println("I ma running before Test");
        WebDriver driver = new ChromeDriver();
        driver.get("https://portal.igbc.in/register");
        System.out.println(driver.getTitle());

        Assert.assertEquals("Cognizant | Udemy Business", driver.getTitle(), "Hey am expecting Cong as tile but i found + "+ driver.getTitle());


    }

@BeforeMethod
public void beforeMethod(){
    System.out.println("Before Method");

    Assert.assertTrue(true);



}



    @Test(priority = 1)
    public void a(){

        System.out.println("login test");
    }


    @Test(priority = 0)
    public void b(){

        System.out.println("002");
    }

    @Test(priority = 2)
    public void d(){

        System.out.println("abcTest");
    }

    @Test(priority = -2)
    public void c(){

        System.out.println("abcdTest");




    }*/




}
