package org.example;

import org.testng.annotations.Test;

public class ClickClass extends SelectClassTests{

    @Test
    public void fffe(){
        get();
    }

    public void get(){
        System.out.println("i am over ridden method");
    }

}
