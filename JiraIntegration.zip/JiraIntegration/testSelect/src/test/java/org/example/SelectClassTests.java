package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class SelectClassTests implements WebDriverInterface{
    WebDriver driver;

    @Test
    public void selectByValue() throws InterruptedException {
        initBrowser();
        System.out.println("test...");
        System.setProperty("webdriver.chrome.driver", "/Users/ishhcomputer/Downloads/chromedriver-mac-x64/chromedriver");
        WebDriver driver = new ChromeDriver();
        driver.get("https://portal.igbc.in/register");
        driver.manage().window().maximize();

        driver.findElement(By.id("select2-title-container")).click();
        Thread.sleep(9000);
        driver.findElement(By.xpath("//li[text()='Mr']")).click();

        // selectpriceCate.click();

       /* Select select = new Select(selectpriceCate);

        select.selectByValue("lohi");
*/

    }

    @Test
    public void selectByValueMs() throws InterruptedException {

        initBrowser();

        driver.findElement(By.id("select2-title-container")).click();

        driver.findElement(By.xpath("//li[text()='Mnnnns']")).click();
    }

    private void initBrowser(){
        System.out.println("test...");
        System.setProperty("webdriver.chrome.driver", "/Users/ishhcomputer/Downloads/chromedriver-mac-x64/chromedriver");
         driver = new ChromeDriver();
        driver.get("https://portal.igbc.in/register");
        driver.manage().window().maximize();

    }

    private void initBrowser(String browser){
        if(browser.equalsIgnoreCase("chrome")){
            System.out.println("test...");
            System.setProperty("webdriver.chrome.driver", "/Users/ishhcomputer/Downloads/chromedriver-mac-x64/chromedriver");
            driver = new ChromeDriver();
            driver.get("https://portal.igbc.in/register");
            driver.manage().window().maximize();
        }
        if(browser.equalsIgnoreCase("firefox")){
            System.out.println("test...");
            System.setProperty("webdriver.firefox.driver", "/Users/ishhcomputer/Downloads/chromedriver-mac-x64/chromedriver");
            WebDriver driver = new FirefoxDriver();
            driver.get("https://portal.igbc.in/register");
            driver.manage().window().maximize();
        }



    }

    public void initBrowser(String browser, int age){

    }

    public String initBrowser( int age, String browser){

        return "";
    }


    public void get() {
        System.out.println("get");
    }
}
