package org.example;

public interface WebDriverInterface {

    public void get();
}
